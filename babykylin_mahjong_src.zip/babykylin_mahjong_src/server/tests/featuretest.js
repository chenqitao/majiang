var m = {
	'k':'asdf',
}

var k = {};

console.log(k == {});

var k = [1,2,3,4];
for(var t in k){
	console.log(t);
}