var t = new Uint8Array([1,2,3,4,5]);
console.log(t);
console.log(t.buffer);
console.log(1 == "1");